package hu.bme.aut.android.publictransporterapp.data

data class Station (
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val stopType: String
)